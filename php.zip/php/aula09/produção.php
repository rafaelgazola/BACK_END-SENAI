 <?php
            if(isset ($_POST["nome"])){
            echo "Seja Bem Vindo(a)" . $_POST["nome"];
            } 

            ?>