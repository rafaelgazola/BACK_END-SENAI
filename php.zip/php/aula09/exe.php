<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Form  </title>
</head>
<body>
    <header>
    <h1>Meu site da minha empres MR Beast</h1>
    </header>
    <main>
        <section>
            <form action="./produção.php" method="POST">
                <label for="nome">Nome: </label>
                <input type="text" name="nome" id="nome"><br>
                <label for="senha">Senha: </label>
                <input password="text" name="senha" id="senha"><br><br>
                <input type="reset" value="Limpar">
                <input type="submit" value="Enviar">
            </form>
            <hr>
           
        </section>
    </main>
</body>
</html>